import Aggregates.EventAggregate;
import Aggregates.EventState;
import Models.EventRawLog;

import java.io.InputStream;
import java.util.ArrayList;

public class Program {

    public static void main(String args[]){

        try {
            String fileName = args[0];
            FileService fileService = new FileService();
            FileParser fileParser = new FileParser();

            InputStream stream = fileService.ReadFile(fileName);
            ArrayList<EventRawLog> eventRawLogs =  fileParser.Parse(stream);

            EventAggregate aggregate = new EventAggregate();
            ArrayList<EventState> events = aggregate.CreateEvents(eventRawLogs);

            System.out.println(events);
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }

}